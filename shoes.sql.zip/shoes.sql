-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2015 at 12:52 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes`
--
CREATE DATABASE IF NOT EXISTS `shoes` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`name`, `id`) VALUES
('Nike', 85),
('Adidas', 86),
('Reebok', 87),
('Adidas', 88),
('Airwalk', 89),
('Dr. Martens', 90),
('Vans', 91),
('Nike', 92),
('Nike', 93),
('Adidas', 94),
('Reebok', 95),
('Nike', 96),
('Adidas', 97),
('Reebok', 98),
('DVS', 99),
('Dr. Martens', 100),
('Airwalk', 101),
('Vans', 102);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`name`, `id`) VALUES
('Foot Locker', 19),
('Foot Action', 20),
('Famous Footwear', 21),
('Champ Sports', 22),
('Journeys', 23);

-- --------------------------------------------------------

--
-- Table structure for table `stores_brands`
--

CREATE TABLE `stores_brands` (
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stores_brands`
--

INSERT INTO `stores_brands` (`store_id`, `brand_id`, `id`) VALUES
(4, 12, 1),
(6, 29, 18),
(6, 30, 19),
(8, 38, 27),
(8, 39, 28),
(18, 52, 41),
(18, 53, 42),
(18, 54, 43),
(18, 55, 44),
(17, 56, 45),
(17, 57, 46),
(17, 58, 47),
(17, 59, 48),
(12, 60, 49),
(12, 61, 50),
(22, 62, 51),
(22, 63, 52),
(22, 64, 53),
(22, 65, 54),
(22, 66, 55),
(21, 67, 56),
(21, 68, 57),
(21, 69, 58),
(21, 70, 59),
(21, 71, 60),
(21, 72, 61),
(23, 73, 62),
(23, 74, 63),
(23, 75, 64),
(23, 76, 65),
(23, 77, 66),
(20, 79, 68),
(20, 80, 69),
(20, 81, 70),
(19, 82, 71),
(19, 83, 72),
(19, 84, 73),
(22, 85, 74),
(22, 86, 75),
(22, 87, 76),
(21, 88, 77),
(21, 89, 78),
(21, 90, 79),
(21, 91, 80),
(21, 92, 81),
(20, 93, 82),
(20, 94, 83),
(20, 95, 84),
(19, 96, 85),
(19, 97, 86),
(19, 98, 87),
(23, 99, 88),
(23, 100, 89),
(23, 101, 90),
(23, 102, 91);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores_brands`
--
ALTER TABLE `stores_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `stores_brands`
--
ALTER TABLE `stores_brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
